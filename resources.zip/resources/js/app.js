require('./bootstrap');
 
window.Alpine = Alpine;

Alpine.start(); 