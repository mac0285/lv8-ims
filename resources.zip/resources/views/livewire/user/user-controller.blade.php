<x-slot name="header">
    <h2 class="text-center font-semibold text-sm text-gray-800 leading-tight">cobntroll USER</h2>
</x-slot> 