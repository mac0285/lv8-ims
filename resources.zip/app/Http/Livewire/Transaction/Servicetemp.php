<?php

namespace App\Http\Livewire\Transaction;

use Livewire\Component;

class Servicetemp extends Component
{
    public function render()
    {
        return view('livewire.transaction.servicetemp');
    }
}
