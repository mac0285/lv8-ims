<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Haruncpi\LaravelUserActivity\Traits\Loggable;
class Password extends Model
{
    use HasFactory;
    use Loggable;
    protected $guarded  = [];
    protected $fillable = [
        'address',
        'user',
        'pass',
        'type',
        'remark',
        'current_team_id',
        'active' 
    ];  
}
